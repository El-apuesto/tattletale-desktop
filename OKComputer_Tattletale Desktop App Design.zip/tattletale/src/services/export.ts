import { TranscriptionResult, TranscriptSegment, ExportOptions } from '../types';

export class ExportService {
  
  generateTXT(transcript: TranscriptionResult, options: ExportOptions): string {
    const { segments } = transcript;
    const { includeSpeakerLabels, includeTimestamps, watermark } = options;
    
    let content = '';
    
    for (const segment of segments) {
      let line = '';
      
      if (includeTimestamps) {
        line += segment.timestamp + ' ';
      }
      
      if (includeSpeakerLabels) {
        line += segment.speaker + ': ';
      }
      
      line += segment.text;
      content += line + '\\n\\n';
    }
    
    if (watermark) {
      content += '\\n---\\nTranscribed with Tattletale';
    }
    
    return content;
  }
  
  generateSRT(transcript: TranscriptionResult, options: ExportOptions): string {
    const { segments } = transcript;
    const { includeSpeakerLabels, watermark } = options;
    
    let content = '';
    
    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];
      
      // SRT index (1-based)
      content += (i + 1) + '\\n';
      
      // Time range
      const startTime = this.formatSRTTime(segment.startTime);
      const endTime = this.formatSRTTime(segment.endTime);
      content += `${startTime} --> ${endTime}\\n`;
      
      // Text with speaker label if requested
      let text = '';
      if (includeSpeakerLabels) {
        text += segment.speaker + ': ';
      }
      text += segment.text;
      content += text + '\\n\\n';
    }
    
    if (watermark) {
      content += '\\nTranscribed with Tattletale';
    }
    
    return content;
  }
  
  generatePDF(transcript: TranscriptionResult, options: ExportOptions): Promise<Blob> {
    // In a real implementation, you would use a library like jsPDF
    // For now, we'll return a mock PDF blob
    return new Promise((resolve) => {
      const content = this.generateTXT(transcript, options);
      const blob = new Blob([content], { type: 'application/pdf' });
      resolve(blob);
    });
  }
  
  generateDOCX(transcript: TranscriptionResult, options: ExportOptions): Promise<Blob> {
    // In a real implementation, you would use a library like docx
    // For now, we'll return a mock DOCX blob
    return new Promise((resolve) => {
      const content = this.generateTXT(transcript, options);
      const blob = new Blob([content], { 
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
      });
      resolve(blob);
    });
  }
  
  private formatSRTTime(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 1000);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')},${ms.toString().padStart(3, '0')}`;
  }
  
  async exportTranscript(
    transcript: TranscriptionResult, 
    options: ExportOptions, 
    filename: string
  ): Promise<boolean> {
    let content: string | Blob;
    let mimeType: string;
    
    switch (options.format) {
      case 'txt':
        content = this.generateTXT(transcript, options);
        mimeType = 'text/plain';
        break;
        
      case 'srt':
        content = this.generateSRT(transcript, options);
        mimeType = 'text/plain';
        break;
        
      case 'pdf':
        content = await this.generatePDF(transcript, options);
        mimeType = 'application/pdf';
        break;
        
      case 'docx':
        content = await this.generateDOCX(transcript, options);
        mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        break;
        
      default:
        throw new Error(`Unsupported export format: ${options.format}`);
    }
    
    // Use the electronAPI to handle the actual file save
    try {
      const success = await window.electronAPI.exportTranscript({
        format: options.format,
        content: content instanceof Blob ? await content.text() : content,
        filename
      });
      
      return success;
    } catch (error) {
      console.error('Export failed:', error);
      return false;
    }
  }
}

// Export a singleton instance
export const exportService = new ExportService();