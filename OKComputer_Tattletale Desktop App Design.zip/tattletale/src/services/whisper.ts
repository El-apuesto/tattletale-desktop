import { Pipeline, pipeline } from '@xenova/transformers';
import { TranscriptionResult, TranscriptSegment } from '../types';

class WhisperService {
  private transcriber: Pipeline | null = null;
  private isLoading = false;

  async initialize() {
    if (this.transcriber || this.isLoading) return;

    this.isLoading = true;
    try {
      // Load the Whisper model
      this.transcriber = await pipeline(
        'automatic-speech-recognition',
        'Xenova/whisper-small.en',
        {
          // Use a local model path for better performance
          // cache_dir: './models',
          // local_files_only: true
        }
      );
    } catch (error) {
      console.error('Failed to load Whisper model:', error);
      throw error;
    } finally {
      this.isLoading = false;
    }
  }

  async transcribeAudio(
    audioData: Float32Array,
    sampleRate: number,
    onProgress?: (progress: number) => void
  ): Promise<TranscriptionResult> {
    if (!this.transcriber) {
      await this.initialize();
    }

    if (!this.transcriber) {
      throw new Error('Whisper model not loaded');
    }

    try {
      // Convert Float32Array to the format expected by the model
      const audio = this.prepareAudioData(audioData, sampleRate);

      // Run transcription
      const result = await this.transcriber(audio, {
        // Return timestamps
        return_timestamps: true,
        // Use the 'transcribe' task
        task: 'transcribe',
        // Language is English (already specified by model)
        language: 'en'
      });

      // Process the result into our format
      return this.processTranscriptionResult(result, audioData.length / sampleRate);
    } catch (error) {
      console.error('Transcription failed:', error);
      throw error;
    }
  }

  private prepareAudioData(audioData: Float32Array, sampleRate: number): any {
    // The model expects audio at 16kHz sample rate
    const targetSampleRate = 16000;
    
    if (sampleRate !== targetSampleRate) {
      // Resample audio to 16kHz
      return this.resampleAudio(audioData, sampleRate, targetSampleRate);
    }
    
    return audioData;
  }

  private resampleAudio(audioData: Float32Array, fromRate: number, toRate: number): Float32Array {
    const ratio = fromRate / toRate;
    const newLength = Math.floor(audioData.length / ratio);
    const resampled = new Float32Array(newLength);

    for (let i = 0; i < newLength; i++) {
      const originalIndex = Math.floor(i * ratio);
      resampled[i] = audioData[originalIndex];
    }

    return resampled;
  }

  private processTranscriptionResult(result: any, totalDuration: number): TranscriptionResult {
    const segments: TranscriptSegment[] = [];
    let speakerCount = 1;
    let lastSpeakerChange = 0;

    // Process chunks from the result
    if (result.chunks) {
      for (let i = 0; i < result.chunks.length; i++) {
        const chunk = result.chunks[i];
        const text = chunk.text.trim();
        
        if (!text) continue;

        const startTime = chunk.timestamp[0];
        const endTime = chunk.timestamp[1];

        // Simple speaker detection based on pauses (2+ seconds)
        const timeSinceLastSpeaker = startTime - lastSpeakerChange;
        if (timeSinceLastSpeaker > 2.0 && segments.length > 0) {
          speakerCount++;
          lastSpeakerChange = startTime;
        }

        segments.push({
          timestamp: this.formatTimestamp(startTime),
          speaker: `Speaker ${Math.min(speakerCount, 3)}`, // Cap at 3 for free tier
          text: text,
          startTime: startTime,
          endTime: endTime
        });
      }
    }

    return {
      segments,
      totalDuration,
      speakers: Math.min(speakerCount, currentTier === 'free' ? 3 : speakerCount)
    };
  }

  private formatTimestamp(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `[${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}]`;
    } else {
      return `[${minutes}:${secs.toString().padStart(2, '0')}]`;
    }
  }

  async dispose() {
    // Clean up resources
    this.transcriber = null;
  }
}

// Export a singleton instance
export const whisperService = new WhisperService();