import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { TranscriptViewer } from './components/TranscriptViewer';
import { SettingsModal } from './components/SettingsModal';
import { UpgradeModal } from './components/UpgradeModal';
import { AppState, TranscriptionResult, License } from '../types';

export const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState | null>(null);
  const [currentTranscript, setCurrentTranscript] = useState<TranscriptionResult | null>(null);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcriptionProgress, setTranscriptionProgress] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [upgradeTrigger, setUpgradeTrigger] = useState<string>('');

  // Load app state on mount
  useEffect(() => {
    loadAppState();
    setupEventListeners();
    
    return () => {
      // Cleanup listeners
      if (window.electronAPI) {
        window.electronAPI.removeAllListeners('transcription-progress');
        window.electronAPI.removeAllListeners('transcription-complete');
        window.electronAPI.removeAllListeners('show-settings');
        window.electronAPI.removeAllListeners('new-transcription');
        window.electronAPI.removeAllListeners('file-selected');
      }
    };
  }, []);

  const loadAppState = async () => {
    try {
      const state = await window.electronAPI.getAppState();
      setAppState(state);
    } catch (error) {
      console.error('Failed to load app state:', error);
    }
  };

  const setupEventListeners = () => {
    // Transcription progress
    window.electronAPI.onTranscriptionProgress((progress: number) => {
      setTranscriptionProgress(progress);
    });

    // Transcription complete
    window.electronAPI.onTranscriptionComplete((result: TranscriptionResult) => {
      setCurrentTranscript(result);
      setIsTranscribing(false);
      setTranscriptionProgress(0);
    });

    // Show settings
    window.electronAPI.onShowSettings(() => {
      setShowSettings(true);
    });

    // New transcription
    window.electronAPI.onNewTranscription(() => {
      handleNewTranscription();
    });

    // File selected from menu
    window.electronAPI.onFileSelected((filePath: string) => {
      handleFileSelect(filePath);
    });
  };

  const handleFileSelect = async (filePath: string) => {
    if (!appState) return;

    // Check usage limits for free tier
    if (appState.currentTier === 'free') {
      const minutesUsed = appState.usage.minutesUsed;
      
      if (minutesUsed >= 60) {
        setUpgradeTrigger('minute_limit_reached');
        setShowUpgrade(true);
        return;
      }
      
      if (minutesUsed >= 50) {
        setUpgradeTrigger('minute_warning');
        setShowUpgrade(true);
      }
    }

    setIsTranscribing(true);
    setTranscriptionProgress(0);
    
    try {
      const success = await window.electronAPI.startTranscription(filePath);
      if (!success) {
        setIsTranscribing(false);
      }
    } catch (error) {
      console.error('Transcription failed:', error);
      setIsTranscribing(false);
    }
  };

  const handleNewTranscription = () => {
    setCurrentTranscript(null);
    setIsTranscribing(false);
    setTranscriptionProgress(0);
  };

  const handleExport = useCallback(async (format: string, content: string, filename: string) => {
    if (!appState) return;

    // Check if format is allowed for current tier
    const isPaidTier = appState.currentTier === 'unlimited' || appState.currentTier === 'student';
    const isPremiumFormat = format === 'pdf' || format === 'docx';
    
    if (isPremiumFormat && !isPaidTier) {
      setUpgradeTrigger('export_limit');
      setShowUpgrade(true);
      return;
    }

    try {
      const success = await window.electronAPI.exportTranscript({
        format,
        content,
        filename
      });
      
      if (success) {
        await window.electronAPI.showMessage({
          type: 'info',
          title: 'Export Complete',
          message: 'Transcript exported successfully!',
          buttons: ['OK']
        });
      }
    } catch (error) {
      console.error('Export failed:', error);
      await window.electronAPI.showMessage({
        type: 'error',
        title: 'Export Failed',
        message: 'Failed to export transcript. Please try again.',
        buttons: ['OK']
      });
    }
  }, [appState]);

  const handleLicenseUpdate = useCallback(async (license: License | null) => {
    setAppState(prev => prev ? { ...prev, license, currentTier: license?.tier || 'free' } : null);
  }, []);

  const handleUsageUpdate = useCallback(async (minutes: number) => {
    if (!appState) return;
    
    const success = await window.electronAPI.updateUsage(minutes);
    if (success) {
      loadAppState();
    }
  }, [appState]);

  // Show loading state while app state loads
  if (!appState) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFAF5]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B1A1A] mx-auto mb-4"></div>
          <p className="text-[#333333] text-lg">Loading Tattletale...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF5] flex flex-col">
      <Header 
        appState={appState}
        onSettingsClick={() => setShowSettings(true)}
        onUpgradeClick={() => {
          setUpgradeTrigger('manual');
          setShowUpgrade(true);
        }}
      />
      
      <main className="flex-1 p-6">
        {!currentTranscript && !isTranscribing && (
          <FileUpload 
            onFileSelect={handleFileSelect}
            isLoading={false}
          />
        )}
        
        {isTranscribing && (
          <div className="max-w-2xl mx-auto">
            <div className="glass-panel p-8 text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[#8B1A1A] mx-auto mb-6"></div>
              <h2 className="text-2xl font-semibold text-[#333333] mb-2">Transcribing Audio</h2>
              <p className="text-gray-600 mb-4">This may take a few minutes depending on the file length.</p>
              <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                <div 
                  className="bg-[#8B1A1A] h-3 rounded-full transition-all duration-300"
                  style={{ width: `${transcriptionProgress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500">{transcriptionProgress}% complete</p>
              <button 
                onClick={async () => {
                  await window.electronAPI.cancelTranscription();
                  setIsTranscribing(false);
                  setTranscriptionProgress(0);
                }}
                className="btn-secondary mt-4"
              >
                Cancel Transcription
              </button>
            </div>
          </div>
        )}
        
        {currentTranscript && !isTranscribing && (
          <TranscriptViewer 
            transcript={currentTranscript}
            currentTier={appState.currentTier}
            onExport={handleExport}
            onNewTranscription={handleNewTranscription}
          />
        )}
      </main>
      
      {showSettings && (
        <SettingsModal 
          appState={appState}
          onClose={() => setShowSettings(false)}
          onLicenseUpdate={handleLicenseUpdate}
        />
      )}
      
      {showUpgrade && (
        <UpgradeModal 
          currentTier={appState.currentTier}
          trigger={upgradeTrigger}
          onClose={() => setShowUpgrade(false)}
          onLicenseActivated={handleLicenseUpdate}
        />
      )}
    </div>
  );
};