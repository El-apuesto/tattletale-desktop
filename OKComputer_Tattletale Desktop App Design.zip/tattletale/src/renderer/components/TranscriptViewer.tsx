import React, { useState, useCallback } from 'react';
import { TranscriptionResult, TranscriptSegment } from '../../types';

interface TranscriptViewerProps {
  transcript: TranscriptionResult;
  currentTier: 'free' | 'unlimited' | 'student';
  onExport: (format: string, content: string, filename: string) => void;
  onNewTranscription: () => void;
}

export const TranscriptViewer: React.FC<TranscriptViewerProps> = ({
  transcript,
  currentTier,
  onExport,
  onNewTranscription
}) => {
  const [editingSegment, setEditingSegment] = useState<number | null>(null);
  const [editedText, setEditedText] = useState('');
  const [transcriptData, setTranscriptData] = useState(transcript);

  const isPaidTier = currentTier === 'unlimited' || currentTier === 'student';

  const handleEditSegment = (index: number, currentText: string) => {
    setEditingSegment(index);
    setEditedText(currentText);
  };

  const handleSaveEdit = (index: number) => {
    if (editingSegment === index) {
      const updatedSegments = [...transcriptData.segments];
      updatedSegments[index] = {
        ...updatedSegments[index],
        text: editedText
      };
      setTranscriptData({
        ...transcriptData,
        segments: updatedSegments
      });
      setEditingSegment(null);
      setEditedText('');
    }
  };

  const handleCancelEdit = () => {
    setEditingSegment(null);
    setEditedText('');
  };

  const generateExportContent = (format: string): string => {
    const { segments } = transcriptData;
    
    switch (format) {
      case 'txt':
        return segments
          .map(segment => `${segment.timestamp} ${segment.speaker}: ${segment.text}`)
          .join('\\n\\n');
          
      case 'srt':
        return segments
          .map((segment, index) => {
            const startTime = formatSRTTime(segment.startTime);
            const endTime = formatSRTTime(segment.endTime);
            return `${index + 1}\\n${startTime} --> ${endTime}\\n${segment.speaker}: ${segment.text}\\n`;
          })
          .join('\\n');
          
      case 'pdf':
      case 'docx':
        // For PDF and DOCX, we'll create a structured text format
        // In a real app, you'd use libraries like jsPDF for PDF generation
        return segments
          .map(segment => `${segment.timestamp}\\n${segment.speaker}\\n${segment.text}\\n\\n---\\n\\n`)
          .join('');
          
      default:
        return '';
    }
  };

  const formatSRTTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 1000);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')},${ms.toString().padStart(3, '0')}`;
  };

  const handleExport = useCallback((format: string) => {
    const content = generateExportContent(format);
    const filename = `transcript_${new Date().toISOString().split('T')[0]}.${format}`;
    
    // Add watermark for free tier
    let finalContent = content;
    if (!isPaidTier && (format === 'txt' || format === 'srt')) {
      finalContent += `\\n\\n---\\nTranscribed with Tattletale`;
    }
    
    onExport(format, finalContent, filename);
  }, [transcriptData, isPaidTier, onExport]);

  const getExportButtonClass = (format: string) => {
    const isPremiumFormat = format === 'pdf' || format === 'docx';
    const isDisabled = isPremiumFormat && !isPaidTier;
    
    return `px-4 py-2 rounded-md font-medium transition-all duration-200 ${
      isDisabled 
        ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
        : 'bg-[#8B1A1A] text-white hover:bg-[#6B0A0A]'
    }`;
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-3xl font-bold text-[#333333] mb-2">Transcription Complete</h2>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <span>{transcriptData.segments.length} segments</span>
            <span>•</span>
            <span>{transcriptData.speakers} speakers</span>
            <span>•</span>
            <span>{Math.round(transcriptData.totalDuration)} seconds</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={onNewTranscription}
            className="btn-secondary"
          >
            New Transcription
          </button>
        </div>
      </div>

      {/* Export Options */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-[#333333]">Export Transcript</h3>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleExport('txt')}
              className={getExportButtonClass('txt')}
            >
              TXT
            </button>
            <button
              onClick={() => handleExport('srt')}
              className={getExportButtonClass('srt')}
            >
              SRT
            </button>
            <button
              onClick={() => handleExport('pdf')}
              className={getExportButtonClass('pdf')}
              disabled={!isPaidTier}
              title={!isPaidTier ? 'Upgrade to export PDF' : ''}
            >
              PDF
            </button>
            <button
              onClick={() => handleExport('docx')}
              className={getExportButtonClass('docx')}
              disabled={!isPaidTier}
              title={!isPaidTier ? 'Upgrade to export DOCX' : ''}
            >
              DOCX
            </button>
          </div>
        </div>
        {!isPaidTier && (
          <p className="text-sm text-gray-500 mt-2">
            💡 Upgrade to unlock PDF and DOCX export formats
          </p>
        )}
      </div>

      {/* Transcript */}
      <div className="space-y-4">
        {transcriptData.segments.map((segment, index) => (
          <div key={index} className="glass-panel p-4 group hover:shadow-lg transition-shadow">
            <div className="flex items-start space-x-4">
              {/* Timestamp */}
              <div className="flex-shrink-0 w-20 text-sm font-mono text-[#8B1A1A] font-medium">
                {segment.timestamp}
              </div>
              
              {/* Speaker and Text */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-[#333333]">{segment.speaker}</span>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                    {editingSegment === index ? (
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleSaveEdit(index)}
                          className="text-green-600 hover:text-green-700 text-sm font-medium"
                        >
                          Save
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="text-gray-500 hover:text-gray-600 text-sm font-medium"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEditSegment(index, segment.text)}
                        className="text-[#8B1A1A] hover:text-[#6B0A0A] text-sm font-medium"
                      >
                        Edit
                      </button>
                    )}
                  </div>
                </div>
                
                {editingSegment === index ? (
                  <textarea
                    value={editedText}
                    onChange={(e) => setEditedText(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#8B1A1A] focus:border-transparent resize-none"
                    rows={3}
                    autoFocus
                  />
                ) : (
                  <p className="text-gray-700 whitespace-pre-wrap">{segment.text}</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {transcriptData.segments.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No transcription segments found.</p>
        </div>
      )}
    </div>
  );
};