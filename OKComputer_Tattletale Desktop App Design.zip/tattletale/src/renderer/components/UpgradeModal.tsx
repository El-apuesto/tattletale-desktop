import React, { useState } from 'react';

interface UpgradeModalProps {
  currentTier: 'free' | 'unlimited' | 'student';
  trigger: string;
  onClose: () => void;
  onLicenseActivated: (license: any) => void;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  currentTier,
  trigger,
  onClose,
  onLicenseActivated
}) => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const getTriggerMessage = () => {
    switch (trigger) {
      case 'minute_warning':
        return {
          title: 'Running Low on Minutes',
          message: 'You have used over 50 minutes this month. Upgrade now to continue transcribing without limits.'
        };
      case 'minute_limit_reached':
        return {
          title: 'Monthly Limit Reached',
          message: 'You have used all 60 minutes this month. Upgrade to unlock unlimited transcription.'
        };
      case 'export_limit':
        return {
          title: 'Export Format Limited',
          message: 'PDF and DOCX exports are only available with paid plans. Upgrade to unlock all export formats.'
        };
      default:
        return {
          title: 'Upgrade Your Plan',
          message: 'Choose the plan that best fits your transcription needs.'
        };
    }
  };

  const handlePlanSelect = async (plan: string) => {
    setSelectedPlan(plan);
    setIsCheckingOut(true);

    try {
      // In a real app, this would integrate with Stripe Checkout
      // For demo purposes, we'll simulate the checkout process
      
      const checkoutUrls = {
        unlimited: 'https://buy.stripe.com/test_unlimited',
        student_monthly: 'https://buy.stripe.com/test_student_monthly',
        student_6month: 'https://buy.stripe.com/test_student_6month'
      };

      const url = checkoutUrls[plan as keyof typeof checkoutUrls];
      
      // Open checkout in default browser
      await window.electronAPI.openExternal(url);
      
      // After payment, user would receive a license key
      // For demo, we'll show a success message with a mock license
      setTimeout(() => {
        setIsCheckingOut(false);
        showLicenseInput(plan);
      }, 2000);
      
    } catch (error) {
      console.error('Checkout failed:', error);
      setIsCheckingOut(false);
    }
  };

  const showLicenseInput = (plan: string) => {
    // Simulate receiving a license key after payment
    const mockLicenses = {
      unlimited: 'UNLIMITED-XXXX-XXXX-XXXX-XXXX',
      student_monthly: 'STUDENT-MONTHLY-XXXX-XXXX-XXXX',
      student_6month: 'STUDENT-6MONTH-XXXX-XXXX-XXXX'
    };

    const licenseKey = mockLicenses[plan as keyof typeof mockLicenses];
    
    // Auto-activate the license
    window.electronAPI.validateLicense(licenseKey).then((license: any) => {
      if (license) {
        window.electronAPI.storeLicense(license);
        onLicenseActivated(license);
        onClose();
      }
    });
  };

  const triggerMessage = getTriggerMessage();

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="glass-panel max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-[#333333] mb-4">
              {triggerMessage.title}
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {triggerMessage.message}
            </p>
          </div>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Free Plan (Current) */}
            <div className="border-2 border-gray-200 rounded-lg p-6 bg-gray-50">
              <div className="text-center mb-4">
                <h3 className="text-xl font-semibold text-[#333333] mb-2">Free</h3>
                <div className="text-3xl font-bold text-[#333333]">$0</div>
                <div className="text-gray-600">Forever</div>
              </div>
              
              <ul className="space-y-2 text-sm text-gray-600 mb-6">
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  60 minutes per month
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  Up to 3 speakers
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  TXT & SRT exports
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  Watermarked exports
                </li>
              </ul>
              
              <div className="text-center">
                <div className="inline-block px-4 py-2 bg-[#8B1A1A] text-white rounded-md font-medium">
                  Current Plan
                </div>
              </div>
            </div>

            {/* Unlimited Plan */}
            <div className="border-2 border-[#8B1A1A] rounded-lg p-6 bg-[#8B1A1A]/5 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-[#8B1A1A] text-white px-3 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
              
              <div className="text-center mb-4">
                <h3 className="text-xl font-semibold text-[#333333] mb-2">Unlimited</h3>
                <div className="text-3xl font-bold text-[#8B1A1A]">$6.99</div>
                <div className="text-gray-600">per month</div>
              </div>
              
              <ul className="space-y-2 text-sm text-gray-600 mb-6">
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  Unlimited transcription
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  Unlimited speakers
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  All export formats
                </li>
                <li className="flex items-center">
                  <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  No watermarks
                </li>
              </ul>
              
              <div className="text-center">
                <button
                  onClick={() => handlePlanSelect('unlimited')}
                  disabled={isCheckingOut}
                  className="btn-primary w-full"
                >
                  {isCheckingOut && selectedPlan === 'unlimited' ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </div>
                  ) : (
                    'Choose Unlimited'
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Student Plans */}
          <div className="text-center mb-8">
            <h3 className="text-xl font-semibold text-[#333333] mb-4">Student Plans</h3>
            <p className="text-gray-600 mb-6">Special pricing for students with .edu email verification</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="text-center mb-4">
                  <h4 className="font-semibold text-[#333333] mb-2">Student Monthly</h4>
                  <div className="text-2xl font-bold text-[#8B1A1A]">$4.00</div>
                  <div className="text-gray-600">per month</div>
                </div>
                
                <ul className="space-y-1 text-sm text-gray-600 mb-4">
                  <li>✓ All Unlimited features</li>
                  <li>✓ .edu email required</li>
                  <li>✓ Verify every 6 months</li>
                </ul>
                
                <button
                  onClick={() => handlePlanSelect('student_monthly')}
                  disabled={isCheckingOut}
                  className="btn-primary w-full"
                >
                  {isCheckingOut && selectedPlan === 'student_monthly' ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </div>
                  ) : (
                    'Choose Student Monthly'
                  )}
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="text-center mb-4">
                  <h4 className="font-semibold text-[#333333] mb-2">Student 6-Month</h4>
                  <div className="text-2xl font-bold text-[#8B1A1A]">$20.00</div>
                  <div className="text-gray-600">one-time payment</div>
                  <div className="text-sm text-green-600 mt-1">Save $4!</div>
                </div>
                
                <ul className="space-y-1 text-sm text-gray-600 mb-4">
                  <li>✓ All Unlimited features</li>
                  <li>✓ .edu email required</li>
                  <li>✓ 6 months access</li>
                </ul>
                
                <button
                  onClick={() => handlePlanSelect('student_6month')}
                  disabled={isCheckingOut}
                  className="btn-primary w-full"
                >
                  {isCheckingOut && selectedPlan === 'student_6month' ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </div>
                  ) : (
                    'Choose Student 6-Month'
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">
              Secure payments powered by Stripe
            </p>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 underline"
            >
              Maybe later
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};