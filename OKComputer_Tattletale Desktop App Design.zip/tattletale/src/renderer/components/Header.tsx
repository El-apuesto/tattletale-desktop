import React from 'react';
import { AppState } from '../../types';

interface HeaderProps {
  appState: AppState;
  onSettingsClick: () => void;
  onUpgradeClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ appState, onSettingsClick, onUpgradeClick }) => {
  const { currentTier, usage } = appState;
  const isUnlimited = currentTier === 'unlimited' || currentTier === 'student';
  
  const usagePercentage = Math.min((usage.minutesUsed / 60) * 100, 100);
  const isWarning = usagePercentage >= 80;

  return (
    <header className="bg-white/80 backdrop-blur border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo and App Name */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[#8B1A1A] rounded-lg flex items-center justify-center">
              <svg 
                className="w-5 h-5 text-white" 
                fill="currentColor" 
                viewBox="0 0 24 24"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-[#8B1A1A]">Tattletale</h1>
          </div>
        </div>

        {/* Usage Meter or Unlimited Badge */}
        <div className="flex items-center space-x-6">
          {isUnlimited ? (
            <div className="flex items-center space-x-2">
              <span className="text-2xl">♾️</span>
              <span className="text-sm font-medium text-[#333333]">
                {currentTier === 'student' ? 'Student Unlimited' : 'Unlimited'}
              </span>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <div className="flex flex-col items-end">
                <span className="text-sm font-medium text-[#333333]">
                  {usage.minutesUsed} / 60 minutes used this month
                </span>
                <div className="usage-bar w-48 mt-1">
                  <div 
                    className={`usage-bar-fill ${isWarning ? 'warning' : ''}`}
                    style={{ width: `${usagePercentage}%` }}
                  ></div>
                </div>
              </div>
              <button 
                onClick={onUpgradeClick}
                className="btn-primary text-sm"
              >
                Upgrade
              </button>
            </div>
          )}
          
          <button 
            onClick={onSettingsClick}
            className="p-2 rounded-md hover:bg-gray-100 transition-colors"
            title="Settings"
          >
            <svg 
              className="w-5 h-5 text-[#333333]" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" 
              />
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" 
              />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
};