import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';

interface FileUploadProps {
  onFileSelect: (filePath: string) => void;
  isLoading: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, isLoading }) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      // In a real app, you'd handle the file upload to the main process
      // For now, we'll simulate it
      onFileSelect(file.path || file.name);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a'],
      'video/*': ['.mp4', '.mov', '.webm']
    },
    maxFiles: 1,
    disabled: isLoading
  });

  const handleFileSelect = async () => {
    try {
      const filePath = await window.electronAPI.selectFile();
      if (filePath) {
        onFileSelect(filePath);
      }
    } catch (error) {
      console.error('File selection failed:', error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-[#333333] mb-4">
          Transcribe Audio & Video Files
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Upload your audio or video files and get accurate, privacy-first transcriptions 
          using Whisper AI - completely offline and secure.
        </p>
      </div>

      <div 
        {...getRootProps()}
        className={`drag-drop-zone ${isDragActive ? 'dragover' : ''} ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} disabled={isLoading} />
        
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-[#8B1A1A]/10 rounded-full flex items-center justify-center">
              <svg 
                className="w-8 h-8 text-[#8B1A1A]" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" 
                />
              </svg>
            </div>
          </div>
          
          <div>
            {isDragActive ? (
              <p className="text-xl font-medium text-[#8B1A1A]">Drop the file here...</p>
            ) : (
              <div className="space-y-2">
                <p className="text-xl font-medium text-[#333333]">
                  Drag & Drop Audio/Video Here
                </p>
                <p className="text-gray-500">
                  or click to browse files
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center space-x-4">
            <div className="w-16 h-px bg-gray-300"></div>
            <span className="text-gray-500 font-medium">or</span>
            <div className="w-16 h-px bg-gray-300"></div>
          </div>

          <button 
            onClick={handleFileSelect}
            disabled={isLoading}
            className="btn-primary text-lg px-8 py-3"
          >
            Choose File
          </button>
        </div>

        <div className="mt-8 text-sm text-gray-500">
          <p className="mb-2">Supported formats:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {['MP3', 'MP4', 'WAV', 'M4A', 'MOV', 'WEBM'].map(format => (
              <span key={format} className="px-2 py-1 bg-gray-100 rounded text-xs">
                {format}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 text-center">
          <div className="w-12 h-12 bg-[#8B1A1A]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-[#8B1A1A]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
            </svg>
          </div>
          <h3 className="font-semibold text-[#333333] mb-2">Privacy First</h3>
          <p className="text-sm text-gray-600">
            All processing happens locally on your device. Your files never leave your computer.
          </p>
        </div>

        <div className="glass-panel p-6 text-center">
          <div className="w-12 h-12 bg-[#8B1A1A]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-[#8B1A1A]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
          <h3 className="font-semibold text-[#333333] mb-2">AI Powered</h3>
          <p className="text-sm text-gray-600">
            Uses OpenAI's Whisper model for highly accurate transcriptions with speaker detection.
          </p>
        </div>

        <div className="glass-panel p-6 text-center">
          <div className="w-12 h-12 bg-[#8B1A1A]/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-[#8B1A1A]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
            </svg>
          </div>
          <h3 className="font-semibold text-[#333333] mb-2">Multiple Formats</h3>
          <p className="text-sm text-gray-600">
            Export your transcriptions as TXT, SRT, PDF, or DOCX files with timestamps and speaker labels.
          </p>
        </div>
      </div>
    </div>
  );
};