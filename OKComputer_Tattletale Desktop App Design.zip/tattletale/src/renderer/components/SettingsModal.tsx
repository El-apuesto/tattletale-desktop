import React, { useState, useEffect } from 'react';
import { AppState, License } from '../../types';

interface SettingsModalProps {
  appState: AppState;
  onClose: () => void;
  onLicenseUpdate: (license: License | null) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  appState,
  onClose,
  onLicenseUpdate
}) => {
  const [licenseKey, setLicenseKey] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const { currentTier, usage, license } = appState;

  useEffect(() => {
    // Load existing license on mount
    const loadLicense = async () => {
      try {
        const storedLicense = await window.electronAPI.getLicense();
        if (storedLicense?.key) {
          setLicenseKey(storedLicense.key);
        }
      } catch (error) {
        console.error('Failed to load license:', error);
      }
    };
    loadLicense();
  }, []);

  const handleActivateLicense = async () => {
    if (!licenseKey.trim()) {
      setError('Please enter a license key');
      return;
    }

    setIsActivating(true);
    setError('');
    setSuccess('');

    try {
      const validatedLicense = await window.electronAPI.validateLicense(licenseKey.trim());
      
      if (validatedLicense) {
        await window.electronAPI.storeLicense(validatedLicense);
        onLicenseUpdate(validatedLicense);
        setSuccess('License activated successfully!');
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        setError('Invalid license key. Please check and try again.');
      }
    } catch (error) {
      setError('Failed to validate license. Please try again.');
    } finally {
      setIsActivating(false);
    }
  };

  const handleDeactivateLicense = async () => {
    try {
      await window.electronAPI.clearLicense();
      onLicenseUpdate(null);
      setLicenseKey('');
      setSuccess('License deactivated successfully!');
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (error) {
      setError('Failed to deactivate license.');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getTierDisplayName = () => {
    switch (currentTier) {
      case 'free':
        return 'Free Tier';
      case 'unlimited':
        return 'Unlimited';
      case 'student':
        return 'Student Unlimited';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="glass-panel max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-[#333333]">Settings</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-md transition-colors"
            >
              <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Current Status */}
          <div>
            <h3 className="text-lg font-semibold text-[#333333] mb-4">Current Status</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Plan:</span>
                <span className="font-medium text-[#333333]">{getTierDisplayName()}</span>
              </div>
              
              {currentTier === 'free' && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Minutes used this month:</span>
                  <span className="font-medium text-[#333333]">
                    {usage.minutesUsed} / 60
                  </span>
                </div>
              )}
              
              {license?.expiryDate && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Expires:</span>
                  <span className="font-medium text-[#333333]">
                    {formatDate(license.expiryDate)}
                  </span>
                </div>
              )}
              
              {license?.studentEmail && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Student Email:</span>
                  <span className="font-medium text-[#333333]">
                    {license.studentEmail}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* License Management */}
          <div>
            <h3 className="text-lg font-semibold text-[#333333] mb-4">License Key</h3>
            
            {currentTier !== 'free' && (
              <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
                <div className="flex items-center">
                  <svg className="w-5 h-5 text-green-500 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                  </svg>
                  <span className="text-green-700 font-medium">Active License</span>
                </div>
                <p className="text-green-600 text-sm mt-1">
                  Your {getTierDisplayName()} license is currently active.
                </p>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label htmlFor="licenseKey" className="block text-sm font-medium text-gray-700 mb-2">
                  {currentTier === 'free' ? 'Enter License Key' : 'Current License Key'}
                </label>
                <input
                  id="licenseKey"
                  type="text"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  className="input-field"
                  disabled={currentTier !== 'free' && currentTier !== 'student'}
                />
              </div>

              {currentTier === 'free' && (
                <div className="flex space-x-3">
                  <button
                    onClick={handleActivateLicense}
                    disabled={isActivating}
                    className="btn-primary flex-1"
                  >
                    {isActivating ? 'Activating...' : 'Activate License'}
                  </button>
                </div>
              )}

              {currentTier !== 'free' && (
                <div className="flex space-x-3">
                  <button
                    onClick={handleDeactivateLicense}
                    className="btn-secondary flex-1"
                  >
                    Deactivate License
                  </button>
                </div>
              )}

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}

              {success && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                  <p className="text-green-700 text-sm">{success}</p>
                </div>
              )}
            </div>
          </div>

          {/* Usage Information */}
          <div>
            <h3 className="text-lg font-semibold text-[#333333] mb-4">Usage Information</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Usage resets on:</span>
                <span className="font-medium text-[#333333]">
                  {formatDate(usage.nextResetDate)}
                </span>
              </div>
              
              {currentTier === 'free' && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Minutes remaining:</span>
                  <span className="font-medium text-[#333333]">
                    {Math.max(0, 60 - usage.minutesUsed)} minutes
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* About */}
          <div>
            <h3 className="text-lg font-semibold text-[#333333] mb-4">About</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>Tattletale v1.0.0</p>
              <p>Privacy-first desktop transcription app using Whisper AI</p>
              <p>
                <button
                  onClick={() => window.electronAPI.openExternal('https://tattletale.app')}
                  className="text-[#8B1A1A] hover:text-[#6B0A0A] underline"
                >
                  Visit our website
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};