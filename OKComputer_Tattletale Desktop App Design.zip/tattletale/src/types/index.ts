export interface TranscriptSegment {
  timestamp: string;
  speaker: string;
  text: string;
  startTime: number;
  endTime: number;
}

export interface TranscriptionResult {
  segments: TranscriptSegment[];
  totalDuration: number;
  speakers: number;
}

export interface UsageStats {
  minutesUsed: number;
  lastResetDate: string;
  nextResetDate: string;
}

export interface License {
  key: string;
  tier: 'free' | 'unlimited' | 'student';
  status: 'active' | 'expired' | 'invalid';
  expiryDate?: string;
  isStudent?: boolean;
  studentEmail?: string;
}

export interface AppState {
  currentTier: 'free' | 'unlimited' | 'student';
  usage: UsageStats;
  license: License | null;
  currentTranscript: TranscriptionResult | null;
  isTranscribing: boolean;
  transcriptionProgress: number;
}

export interface ExportOptions {
  format: 'txt' | 'srt' | 'pdf' | 'docx';
  includeSpeakerLabels: boolean;
  includeTimestamps: boolean;
  watermark: boolean;
}